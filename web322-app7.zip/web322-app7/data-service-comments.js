const mongoose = require('mongoose');
let Schema = mongoose.Schema;


const commentSchema = new Schema({
    "authorName": String,
    "authorEmail": String,
    "subject": String,
    "commentText": String,
    "postedDate": Date,
    "replies": [{
        "comment_id": String,
        "authorName": String,
        "authorEmail": String,
        "commentText": String,
        "repliedDate": Date
    }]
});

let Comment;


module.exports.initialize = function () {
    return new Promise(function (resolve, reject) {
        let db = mongoose.createConnection("mongodb://krnshah:krn@ds045734.mlab.com:45734/krnshah");

        db.on('error', (err) => {
            reject(err);
        });
        db.once('open', () => {
            Comment = db.model("comments", commentSchema);
            resolve();
        });
    });
};


module.exports.addComment = function (data) {
    return new Promise((resolve, reject) => {
        data.postedDate = Date.now();
        let newComment = new Comment(data);
        newComment.save(function (err) {
            if (err)
                reject("There was an error saving the comment" + err);
            else
                resolve(newComment._id);
        });
    });
}

module.exports.getAllComments = function () {
    return Comment.find().sort({
        postedDate: 1
    }).exec();
}



module.exports.addReply = function (data) {
    data.repliedDate = Date.now();
    
    return new Promise ((resolve, reject) => {
        if(data._id == data.comment_id){
            Comment.update({_id: data.comment_id},
            {$addToSet: {replies:data}},{multi:false}).exec();
            resolve(data);
        }
    }).catch((err) => {
        reject("Unable to Add Reply")
    })
}
