/********************************************************************************* 
*  WEB322 – Assignment 06  
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students. 
*  
*  Name: Karan Shah Student ID: 129965166 Date: 20th December 2017 
* 
*  Online (Heroku) Link: https://krnapp6.herokuapp.com/
* 
********************************************************************************/
var HTTP_PORT = process.env.PORT || 8080;
var express = require("express");
var app = express();
const exphbs = require('express-handlebars');
const bodyParser = require('body-parser');
const dataServiceComments = require("./data-service-comments.js");

var db = require("./data-service.js");
app.use(express.static(__dirname + '/public/'));
var path = require("path");

app.use(bodyParser.urlencoded({ extended: true }));

app.engine(".hbs", exphbs({
  extname: ".hbs",
  defaultLayout: 'layout',
  helpers: {
    equal: function (lvalue, rvalue, options) {
      if (arguments.length < 3)
        throw new Error("Handlebars Helper equal needs 2 parameters");
      if (lvalue != rvalue) {
        return options.inverse(this);
      } else {
        return options.fn(this);
      }
    }
  }
}));
app.set("view engine", ".hbs");



app.get("/", function (request, response) {

  response.render("home");
});



app.get("/employees", function (request, response) {

  if (request.query.status) {
    db.getEmployeesByStatus(request.query.status).then(function (data) {
      response.render("employeeList", { data: data, title: "Employees" });
    }).catch((err) => {
      response.render("employeeList", { data: {}, title: "Employees" });
    });

    /////////////////////////////////////////////
  }

  else if (request.query.department) {
    db.getEmployeesByDepartment(request.query.department).then((data) => {
      response.render("employeeList", { data: data, title: "Employees" });
    }).catch((err) => {
      response.render("employeeList", { data: {}, title: "Employees" });
    });
  }
  /////////////////////
  else if (request.query.manager) {
    db.getEmployeesByManager(request.query.manager).then((data) => {
      response.render("employeeList", { data: data, title: "Employees" });
    }).catch((err) => {
      response.render("employeeList", { data: {}, title: "Employees" });
    });
  } else {
    db.getAllEmployees().then((data) => {
      response.render("employeeList", { data: data, title: "Employees" });
    }).catch((err) => {
      response.render("employeeList", { data: {}, title: "Employees" });
    });
  }
});



/*app.get("/employee/:empNum", function (request, response) {
  db.getEmployeeByNum(request.params.empNum).then((data) => {
    response.render("employee", { data: data[0] });
  }).catch((err) => {
    response.status(404).send("Employee Not Found!!!");
  });
});*/

app.get("/employee/:empNum", (req, res) => {
    // initialize an empty object to store the values
    let viewData = {};
    db.getEmployeeByNum(req.params.empNum)
        .then((data) => {
            viewData.data = data; //store employee data in the "viewData" object as "data"
        }).catch(() => {
            viewData.data = null; // set employee to null if there was an error 
        }).then(db.getDepartments)
        .then((data) => {
            viewData.departments = data; // store department data in the "viewData" object as "departments"
            // loop through viewData.departments and once we have found the departmentId that matches
            // the employee's "department" value, add a "selected" property to the matching 
            // viewData.departments object
            for (let i = 0; i < viewData.departments.length; i++) {
                if (viewData.departments[i].departmentId == viewData.data[0].department) {
                    viewData.departments[i].selected = true;
                }
            }
        }).catch(() => {
            viewData.departments = []; // set departments to empty if there was an error
        }).then(() => {
            if (viewData.data == null) { // if no employee -return an error
                res.status(404).send("Employee Not Found");
            } else {
                res.render("employee", { viewData: viewData }); // render the "employee" view
            }
        });
});

app.post("/employee/update", (req, res) => {
  db.updateEmployee(req.body).then((data) => {

    res.redirect("/employees");
  }).catch((err) => {
    console.log(err);
  })
});

app.get("/employee/delete/:empNum", (req, res) => {
  db.deleteEmployeeByNum(req.params.empNum).then((data) => {
    res.redirect("/employees");
  }).catch((err) => {
    res.status(500).send("Unable to Remove Employee / Employee not found");
  });
});

app.get("/managers", function (request, response) {
  db.getManagers().then(function (data) {
    response.render("employeeList", { data: data, title: "Employees (Managers)" });
  }).catch(function (err) {
    res.render("employeeList", { data: {}, title: "Employees (Managers)" });
  });
});

app.get("/departments", function (request, response) {
  db.getDepartments().then(function (data) {
    response.render("departmentList", { data: data, title: "Departments" });
  }).catch(function (err) {
    response.render("departmentList", { data: data, title: "Departments" });
  });
});
app.get("/departments/add", function (req, res) {
  res.render("addDepartment");
});

app.post("/departments/add", (req, res) => {
  db.addDepartment(req.body).then((data) => {

    res.redirect("/departments");
  }).catch((err) => {
    console.log(err);
  });
});

app.get("/department/:departmentId", (req, res) => {
  db.getDepartmentById(req.params.departmentId).then((data) => {
    res.render("department", {
      data: data
    });
  }).catch((err) => {
    res.status(404).send("Department Not Found");
  });
});

app.post("/department/update", (req, res) => {
  db.updateDepartment(req.body).then((data) => {
    res.redirect("/departments");
  });
});

app.get("/employees/add", (req, res) => {
  db.getDepartments().then(function (data) {
    res.render("addEmployee", { data: data });
  }).catch();
});

app.post("/employees/add", (req, res) => {
  db.addEmployee(req.body).then((data) => {

    res.redirect("/employees");
  }).catch((err) => {
    console.log(err);
  });
});

app.post("/about/addComment", (req,res) => {
  dataServiceComments.addComment(req.body).then((data)=>{
    res.redirect("/about")
  }).catch((err)=>{
    console.log(err);
    res.redirect("/about");
  });
});

app.post("/about/addReply", (req,res)=>{
  dataServiceComments.addReply(req.body).then((data)=>{
    res.redirect("/about");

  }).catch((err)=>{
    console.log(err);
    res.redirect("/about");
    
  });
});


app.get("/about",(req,res)=>{
  dataServiceComments.getAllComments().then((data)=>{
    res.render("about", {data: data});
  }).catch((err)=>{
    res.render("about");
  })
})

app.use(function (request, response) {
  response.status(404).send("ERROR 404 : Page Not Found");
});


dataServiceComments.initialize().then(()=>{
  console.log("krn");
  app.listen(HTTP_PORT, onHttpStart());

}).catch(()=>{
  console.log("unable to start dataService");
});

var onHttpStart = function (){
  console.log("Server Listening on "+ HTTP_PORT);
};